let imagemEstrada;
let imagemAtor;
let imagemCarros;

function preload(){
  imagemEstrada = loadImage('imagens/estrada.png') //carregar imagem
  imagemAtor = loadImage('imagens/ator-1.png')
  //array imagens carros
  imagemCarros = [loadImage('imagens/carro-1.png'),
                  loadImage('imagens/carro-2.png'),
                  loadImage('imagens/carro-3.png'),
                  loadImage('imagens/carro-1.png'),
                  loadImage('imagens/carro-2.png'),
                  loadImage('imagens/carro-3.png')]
}